# Access Pass Membership

Excel File: Access_Pass_Members_Philly.xlsx
Source Link: https://betterbikeshare.org/wp-content/uploads/2018/12/1-pager-access-pass-12_18_18.pdf
Story Arch: Resolution
# % of Traffic Stops in Hoover, Foster, Clawson and McClymonds

Excel File: _of_Traffic_Stops_in_Hoover_Foster_Clawson_and_McClymonds_by_Race.xlsx
Source Link: https://www.bicycling.com/culture/a33383540/cycling-while-black-police/
Story Arch: Conflict
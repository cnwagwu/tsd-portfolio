# Philadephia Pandemic Ridership Increase

Brief Description: Automated Bike Counters recorded 471% spike in Cyclists on Kelly Drive Trail from March 1 to March 18
Excel File: Philadelphia_Kelly_Drive_Trail.xlsx
Source Link: https://energynews.us/2020/04/16/west/the-pandemic-is-fueling-a-biking-boom-will-it-last/
Story Arch: Set Up
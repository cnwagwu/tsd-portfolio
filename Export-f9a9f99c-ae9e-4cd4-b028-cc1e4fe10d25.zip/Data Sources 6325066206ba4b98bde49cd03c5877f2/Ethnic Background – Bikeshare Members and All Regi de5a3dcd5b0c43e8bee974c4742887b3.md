# Ethnic Background – Bikeshare Members and All Regional Employees

Brief Description: Breakdown of Bikeshare member ethnicities versus the employees
Data Source Name: Capital Bikeshare Ethnic Background - Bikeshare Members and All Regional Employees
Excel File: Capital_Bikeshare_-_Ethnic_Background_of_Bikeshare_Members_and_All_Regional_Employees_(2016).xlsx
Source Link: https://d21xlh2maitm24.cloudfront.net/wdc/Capital-Bikeshare_2016MemberSurvey_Final-Report.pdf?mtime=20170303165531
Story Arch: Conflict
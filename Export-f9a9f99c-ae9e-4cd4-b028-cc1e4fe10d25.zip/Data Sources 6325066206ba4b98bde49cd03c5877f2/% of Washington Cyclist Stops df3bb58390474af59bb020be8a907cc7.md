# % of Washington Cyclist Stops

Excel File: _of_Traffic_Stops_in_Hoover_Foster_Clawson_and_McClymonds_by_Race%201.xlsx
Source Link: https://www.bicycling.com/culture/a33383540/cycling-while-black-police/
Story Arch: Conflict